def foo123():
    print("ok new")